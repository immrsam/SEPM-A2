/**
 * 
 */
/**
 * @author Sammy
 *
 */
module a2 {
}