package a2;

import java.util.Map;
import java.util.Scanner;

public class MyApp {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);

		Map<String, StaffMember> staff = ImportData.importStaffMap();

		System.out.print("Enter email: ");
		String username = input.nextLine();
		System.out.print("Enter password: ");
		String password = input.nextLine();
		StaffMember user = staff.get(username);
		if (user != null) {
			if(user.getPassword().equals(password)) {
				System.out.println("Found user: " + user.getUserId());
				System.out.println("Name: " + user.getfName() + " " + user.getlName());
				System.out.println("Phone: " + user.getPhoneNumber());
				System.out.println("Email: " + user.getEmail());
			}
			else {
				System.out.println("Incorrect Username or Password");
			}
		    
		} else {
		    System.out.println("Incorrect Username or Password");
		}

//		Menu.Login(input);

		input.close();
		
	}
}
