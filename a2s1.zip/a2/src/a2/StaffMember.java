package a2;

public class StaffMember extends User {

	public StaffMember(int userId, String fName, String lName, String email, String phoneNumber ,String password) {
		super(userId, fName, lName, email, phoneNumber, password);

	}

}
