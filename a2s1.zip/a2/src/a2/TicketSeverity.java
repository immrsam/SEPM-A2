package a2;

public enum TicketSeverity {
	LOW, HIGH;
}
