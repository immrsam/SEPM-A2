package a2;

public enum TicketStatus {
	OPEN, CLOSE;
}
